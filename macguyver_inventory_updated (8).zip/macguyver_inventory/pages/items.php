<?php
define('BASE_URL', '/macguyver_inventory/');
$pageTitle = 'Inventory Items';
require_once '../includes/header.php';
$db = getDB();
$msg = ''; $msgType = 'success';

$uploadDir = __DIR__ . '/../uploads/items/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

function handleImageUpload($uploadDir) {
    if (empty($_FILES['item_image']['name'])) return null;
    $file = $_FILES['item_image'];
    $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
    if (!in_array($file['type'], $allowed)) return false;
    if ($file['size'] > 5 * 1024 * 1024) return false; // 5MB max
    $ext  = pathinfo($file['name'], PATHINFO_EXTENSION);
    $name = 'item_' . uniqid() . '.' . strtolower($ext);
    if (move_uploaded_file($file['tmp_name'], $uploadDir . $name)) return $name;
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name   = $db->real_escape_string(trim($_POST['name']));
        $code   = $action === 'add' ? $db->real_escape_string(trim($_POST['item_code'])) : '';
        $desc   = $db->real_escape_string(trim($_POST['description'] ?? ''));
        $cat    = (int)($_POST['category_id'] ?? 0);
        $sup    = (int)($_POST['supplier_id'] ?? 0);
        $unit   = $db->real_escape_string(trim($_POST['unit'] ?? 'pcs'));
        $qty    = (int)($_POST['quantity'] ?? 0);
        $rol    = (int)($_POST['reorder_level'] ?? 5);
        $price  = (float)($_POST['unit_price'] ?? 0);
        $loc    = $db->real_escape_string(trim($_POST['location'] ?? ''));
        $status = $db->real_escape_string($_POST['status'] ?? 'active');

        $imgResult = handleImageUpload($uploadDir);
        $imgSql = '';

        if ($action === 'add') {
            if (empty($code)) $code = generateCode('ITM');
            $imgCol = '';
            if ($imgResult) {
                $imgName = $db->real_escape_string($imgResult);
                $imgCol  = ",'$imgName'";
                $imgSql  = ",image";
            }
            $db->query("INSERT INTO items (item_code,name,description,category_id,supplier_id,unit,quantity,reorder_level,unit_price,location,status$imgSql) VALUES ('$code','$name','$desc',$cat,$sup,'$unit',$qty,$rol,$price,'$loc','$status'$imgCol)");
            logActivity($_SESSION['user_id'], 'add_item', "Added item: $name");
            $msg = "Item '$name' added successfully!";
        } else {
            $id = (int)$_POST['item_id'];
            // Delete old image if replacing
            if ($imgResult) {
                $old = $db->query("SELECT image FROM items WHERE id=$id")->fetch_assoc();
                if ($old && $old['image'] && file_exists($uploadDir . $old['image'])) {
                    unlink($uploadDir . $old['image']);
                }
                $imgName = $db->real_escape_string($imgResult);
                $imgSql  = ",image='$imgName'";
            }
            // Handle remove image
            if (isset($_POST['remove_image']) && $_POST['remove_image'] == '1') {
                $old = $db->query("SELECT image FROM items WHERE id=$id")->fetch_assoc();
                if ($old && $old['image'] && file_exists($uploadDir . $old['image'])) unlink($uploadDir . $old['image']);
                $imgSql = ",image=NULL";
            }
            $db->query("UPDATE items SET name='$name',description='$desc',category_id=$cat,supplier_id=$sup,unit='$unit',reorder_level=$rol,unit_price=$price,location='$loc',status='$status'$imgSql WHERE id=$id");
            logActivity($_SESSION['user_id'], 'edit_item', "Edited item: $name");
            $msg = "Item '$name' updated!";
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['item_id'];
        $item = $db->query("SELECT name,image FROM items WHERE id=$id")->fetch_assoc();
        if ($item && $item['image'] && file_exists($uploadDir . $item['image'])) unlink($uploadDir . $item['image']);
        $db->query("DELETE FROM items WHERE id=$id");
        logActivity($_SESSION['user_id'], 'delete_item', "Deleted item: " . ($item['name'] ?? ''));
        $msg = "Item deleted."; $msgType = 'warning';
    }
}

$filter  = $_GET['filter'] ?? '';
$search  = $db->real_escape_string($_GET['search'] ?? '');
$perPage = 20;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where = "WHERE 1=1";
if ($filter === 'low') $where .= " AND i.quantity <= i.reorder_level";
if ($filter === 'out') $where .= " AND i.quantity = 0";
if ($search) $where .= " AND (i.name LIKE '%$search%' OR i.item_code LIKE '%$search%')";

$total      = $db->query("SELECT COUNT(*) c FROM items i $where")->fetch_assoc()['c'];
$totalPages = max(1, ceil($total / $perPage));

$items = $db->query("SELECT i.*,c.name cat_name,s.name sup_name FROM items i LEFT JOIN categories c ON i.category_id=c.id LEFT JOIN suppliers s ON i.supplier_id=s.id $where ORDER BY i.updated_at DESC LIMIT $perPage OFFSET $offset");
$cats  = $db->query("SELECT * FROM categories ORDER BY name");
$sups  = $db->query("SELECT * FROM suppliers ORDER BY name");

$filterQS = http_build_query(array_filter(['filter'=>$filter,'search'=>$_GET['search']??'']));
$filterQS = $filterQS ? '&'.$filterQS : '';
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jsbarcode/3.11.5/JsBarcode.all.min.js"></script>

<style>
.item-thumb {
  width:48px; height:48px; object-fit:cover; border-radius:8px;
  border:2px solid var(--gray-200); cursor:pointer; transition:transform .2s;
}
.item-thumb:hover { transform:scale(1.1); box-shadow:0 4px 12px rgba(0,0,0,.2); }
.no-thumb {
  width:48px; height:48px; border-radius:8px; border:2px dashed var(--gray-200);
  display:flex; align-items:center; justify-content:center; color:var(--gray-400);
  font-size:.8rem; background:var(--gray-50); cursor:default;
}
.img-preview-wrap {
  position:relative; display:inline-block; margin-top:8px;
}
.img-preview-wrap img {
  max-width:160px; max-height:120px; border-radius:8px;
  border:2px solid var(--gray-200); object-fit:cover; display:block;
}
.img-preview-wrap .remove-img {
  position:absolute; top:-8px; right:-8px; width:22px; height:22px;
  background:var(--red); border:none; border-radius:50%; color:#fff;
  font-size:.65rem; cursor:pointer; display:flex; align-items:center; justify-content:center;
}
.img-lightbox {
  position:fixed; inset:0; background:rgba(0,0,0,.85); z-index:9999;
  display:flex; align-items:center; justify-content:center;
}
.img-lightbox img { max-width:90vw; max-height:90vh; border-radius:12px; box-shadow:0 8px 40px rgba(0,0,0,.6); }
.img-lightbox-close {
  position:absolute; top:20px; right:24px; background:none; border:none;
  color:#fff; font-size:2rem; cursor:pointer; line-height:1;
}
.upload-area {
  border:2px dashed var(--gray-200); border-radius:10px; padding:18px;
  text-align:center; cursor:pointer; transition:all .2s; background:var(--gray-50);
}
.upload-area:hover { border-color:var(--navy); background:#f0f4ff; }
.upload-area i { font-size:1.4rem; color:var(--gray-400); margin-bottom:6px; }
.upload-area p { font-size:.78rem; color:var(--gray-600); }
.pagination{display:flex;align-items:center;gap:6px;justify-content:flex-end;padding:14px 16px;flex-wrap:wrap}
.pag-btn{padding:5px 11px;border-radius:6px;border:1px solid var(--gray-200);background:#fff;color:var(--navy);font-size:.82rem;font-weight:600;text-decoration:none;transition:all .2s}
.pag-btn:hover{background:var(--navy);color:#fff}
.pag-btn.active{background:var(--navy);color:#fff;border-color:var(--navy)}
.pag-btn.disabled{opacity:.4;pointer-events:none}
</style>

<div class="page-header">
  <div><h1>Inventory Items</h1><p>Manage all inventory items and stock levels</p></div>
  <div style="display:flex;gap:10px;flex-wrap:wrap;">
    <?php if(isAdmin() || $_SESSION['role']==='staff'): ?>
    <button class="btn btn-gold" onclick="openModal('addModal')"><i class="fas fa-plus"></i> Add Item</button>
    <?php endif; ?>
  </div>
</div>

<?php if($msg): ?><div class="alert alert-<?= $msgType ?>"><i class="fas fa-check-circle"></i><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-boxes" style="color:var(--gold)"></i> All Items (<?= number_format($total) ?>)</h2>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
      <form method="GET" style="display:flex;gap:8px">
        <input type="text" name="search" class="search-input" placeholder="Search items..." value="<?= htmlspecialchars($search) ?>">
        <select name="filter" class="form-control" style="width:auto">
          <option value="">All Items</option>
          <option value="low" <?= $filter==='low'?'selected':'' ?>>Low Stock</option>
          <option value="out" <?= $filter==='out'?'selected':'' ?>>Out of Stock</option>
        </select>
        <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-search"></i></button>
        <?php if($search||$filter): ?><a href="items.php" class="btn btn-secondary btn-sm">Clear</a><?php endif; ?>
      </form>
    </div>
  </div>
  <div class="table-responsive">
    <table id="itemsTable">
      <thead>
        <tr><th>#</th><th>Photo</th><th>Barcode</th><th>Code</th><th>Name</th><th>Category</th><th>Unit Price</th><th>Qty</th><th>Reorder Lvl</th><th>Location</th><th>Status</th><th>Actions</th></tr>
      </thead>
      <tbody>
      <?php $rowNum=$offset+1; while($r=$items->fetch_assoc()): ?>
      <tr>
        <td><?= $rowNum++ ?></td>
        <td style="text-align:center;">
          <?php if($r['image'] && file_exists($uploadDir.$r['image'])): ?>
          <img src="<?= BASE_URL ?>uploads/items/<?= htmlspecialchars($r['image']) ?>"
               class="item-thumb"
               onclick="showLightbox('<?= BASE_URL ?>uploads/items/<?= htmlspecialchars($r['image']) ?>','<?= htmlspecialchars(addslashes($r['name'])) ?>')"
               alt="<?= htmlspecialchars($r['name']) ?>">
          <?php else: ?>
          <div class="no-thumb"><i class="fas fa-image"></i></div>
          <?php endif; ?>
        </td>
        <td style="text-align:center;">
          <svg class="barcode-svg" id="bc-<?= $r['id'] ?>" data-code="<?= sanitize($r['item_code']) ?>"
               onclick="showBarcode(<?= json_encode($r) ?>)" title="Click to enlarge" style="cursor:pointer;display:block;margin:0 auto;"></svg>
        </td>
        <td><span class="item-code"><?= sanitize($r['item_code']) ?></span></td>
        <td><strong><?= sanitize($r['name']) ?></strong><br><small style="color:var(--gray-400)"><?= sanitize($r['description'] ?? '') ?></small></td>
        <td><?= sanitize($r['cat_name'] ?? '-') ?></td>
        <td><?= formatCurrency($r['unit_price']) ?></td>
        <td class="<?= $r['quantity']==0?'out-stock':($r['quantity']<=$r['reorder_level']?'low-stock':'') ?>">
          <?= $r['quantity'] ?> <?= sanitize($r['unit']) ?>
        </td>
        <td><?= $r['reorder_level'] ?></td>
        <td><?= sanitize($r['location'] ?? '-') ?></td>
        <td>
          <?php if($r['status']==='active'): ?><span class="badge badge-success">Active</span>
          <?php elseif($r['status']==='inactive'): ?><span class="badge badge-secondary">Inactive</span>
          <?php else: ?><span class="badge badge-danger">Discontinued</span><?php endif; ?>
        </td>
        <td>
          <button class="btn btn-sm btn-primary" onclick='editItem(<?= json_encode($r) ?>)'><i class="fas fa-edit"></i></button>
          <?php if(isAdmin()): ?>
          <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="item_id" value="<?= $r['id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger btn-delete"><i class="fas fa-trash"></i></button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endwhile; ?>
      <?php if($total===0): ?><tr><td colspan="12"><div class="empty-state"><i class="fas fa-inbox"></i><p>No items found.</p></div></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($totalPages>1): ?>
  <div class="pagination">
    <a href="?page=1<?= $filterQS ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-double-left"></i></a>
    <a href="?page=<?= max(1,$page-1) ?><?= $filterQS ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-left"></i></a>
    <?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++): ?>
      <a href="?page=<?= $p ?><?= $filterQS ?>" class="pag-btn <?= $p==$page?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
    <a href="?page=<?= min($totalPages,$page+1) ?><?= $filterQS ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-right"></i></a>
    <a href="?page=<?= $totalPages ?><?= $filterQS ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-double-right"></i></a>
    <span style="font-size:.8rem;color:var(--gray-600);margin-left:6px">Page <?= $page ?> of <?= $totalPages ?> &nbsp;|&nbsp; Showing <?= $offset+1 ?>&#8211;<?= min($offset+$perPage,$total) ?> of <?= number_format($total) ?></span>
  </div>
  <?php endif; ?>
</div>

<!-- Image Lightbox -->
<div class="img-lightbox" id="lightbox" style="display:none;" onclick="closeLightbox()">
  <button class="img-lightbox-close" onclick="closeLightbox()"><i class="fas fa-times"></i></button>
  <img id="lightboxImg" src="" alt="">
</div>

<!-- Barcode Modal -->
<div class="modal-overlay" id="barcodeModal">
  <div class="modal" style="max-width:420px;">
    <div class="modal-header">
      <h3><i class="fas fa-barcode"></i> Item Barcode</h3>
      <button class="modal-close" onclick="closeModal('barcodeModal')"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body" style="padding:24px;text-align:center;">
      <div id="bcItemName" style="font-family:'Barlow Condensed',sans-serif;font-size:1.2rem;font-weight:800;color:var(--navy);margin-bottom:4px;"></div>
      <div id="bcItemCode" style="font-family:monospace;font-size:.78rem;background:var(--gray-100);border:1px solid var(--gray-200);display:inline-block;padding:3px 12px;border-radius:4px;color:var(--navy);margin-bottom:18px;letter-spacing:.5px;"></div>
      <div style="background:#fff;padding:18px 20px 12px;border-radius:12px;border:2px solid var(--navy);display:inline-block;box-shadow:0 4px 20px rgba(0,0,0,.1);">
        <svg id="bcLarge" style="display:block;max-width:100%;"></svg>
      </div>
      <div style="margin-top:12px;font-size:.78rem;color:var(--gray-600);">🔍 Scan with any barcode reader or scanner gun</div>
      <div id="bcItemMeta" style="margin-top:8px;font-size:.74rem;color:var(--gray-400);line-height:1.7;"></div>
      <div style="margin-top:20px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
        <button class="btn btn-primary btn-sm" onclick="printBarcode()"><i class="fas fa-print"></i> Print</button>
        <button class="btn btn-gold btn-sm" onclick="downloadBarcode()"><i class="fas fa-download"></i> Download</button>
        <button class="btn btn-secondary btn-sm" onclick="closeModal('barcodeModal')"><i class="fas fa-times"></i> Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Add Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal modal-lg">
    <div class="modal-header">
      <h3><i class="fas fa-plus"></i> Add New Item</h3>
      <button class="modal-close" onclick="closeModal('addModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="add">
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-group"><label class="form-label">Item Code</label><input type="text" name="item_code" class="form-control" placeholder="Auto-generated if blank"></div>
          <div class="form-group"><label class="form-label">Item Name *</label><input type="text" name="name" class="form-control" required></div>
        </div>
        <div class="form-group"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
        <!-- IMAGE UPLOAD -->
        <div class="form-group">
          <label class="form-label"><i class="fas fa-camera" style="color:var(--navy)"></i> Item Photo</label>
          <div class="upload-area" onclick="document.getElementById('add_image_input').click()">
            <i class="fas fa-cloud-upload-alt"></i>
            <p>Click to upload photo (JPG, PNG, WEBP — max 5MB)</p>
          </div>
          <input type="file" id="add_image_input" name="item_image" accept="image/*" style="display:none" onchange="previewImage(this,'add_preview')">
          <div id="add_preview" style="margin-top:8px;"></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label class="form-label">Category</label>
            <select name="category_id" class="form-control"><option value="0">-- Select --</option>
            <?php $cats->data_seek(0); while($c=$cats->fetch_assoc()): ?><option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option><?php endwhile; ?>
            </select></div>
          <div class="form-group"><label class="form-label">Supplier</label>
            <select name="supplier_id" class="form-control"><option value="0">-- Select --</option>
            <?php $sups->data_seek(0); while($s=$sups->fetch_assoc()): ?><option value="<?= $s['id'] ?>"><?= sanitize($s['name']) ?></option><?php endwhile; ?>
            </select></div>
        </div>
        <div class="form-grid-3">
          <div class="form-group"><label class="form-label">Unit</label><input type="text" name="unit" class="form-control" value="pcs"></div>
          <div class="form-group"><label class="form-label">Initial Qty</label><input type="number" name="quantity" class="form-control" value="0" min="0"></div>
          <div class="form-group"><label class="form-label">Reorder Level</label><input type="number" name="reorder_level" class="form-control" value="5" min="0"></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label class="form-label">Unit Price (₱)</label><input type="number" name="unit_price" class="form-control" value="0" step="0.01" min="0"></div>
          <div class="form-group"><label class="form-label">Storage Location</label><input type="text" name="location" class="form-control"></div>
        </div>
        <div class="form-group"><label class="form-label">Status</label>
          <select name="status" class="form-control"><option value="active">Active</option><option value="inactive">Inactive</option><option value="discontinued">Discontinued</option></select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" class="btn btn-gold"><i class="fas fa-save"></i> Save Item</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="editModal">
  <div class="modal modal-lg">
    <div class="modal-header">
      <h3><i class="fas fa-edit"></i> Edit Item</h3>
      <button class="modal-close" onclick="closeModal('editModal')"><i class="fas fa-times"></i></button>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="item_id" id="edit_id">
      <input type="hidden" name="remove_image" id="edit_remove_image" value="0">
      <div class="modal-body">
        <div class="form-grid">
          <div class="form-group"><label class="form-label">Item Code</label><input type="text" id="edit_code" class="form-control" readonly style="background:var(--gray-100)"></div>
          <div class="form-group"><label class="form-label">Item Name *</label><input type="text" name="name" id="edit_name" class="form-control" required></div>
        </div>
        <div class="form-group"><label class="form-label">Description</label><textarea name="description" id="edit_desc" class="form-control" rows="2"></textarea></div>
        <!-- IMAGE UPLOAD -->
        <div class="form-group">
          <label class="form-label"><i class="fas fa-camera" style="color:var(--navy)"></i> Item Photo</label>
          <div id="edit_current_img_wrap" style="display:none;margin-bottom:10px;">
            <p style="font-size:.78rem;color:var(--gray-600);margin-bottom:6px;">Current photo:</p>
            <div class="img-preview-wrap">
              <img id="edit_current_img" src="" alt="Current">
              <button type="button" class="remove-img" onclick="removeCurrentImage()" title="Remove photo"><i class="fas fa-times"></i></button>
            </div>
          </div>
          <div class="upload-area" onclick="document.getElementById('edit_image_input').click()">
            <i class="fas fa-cloud-upload-alt"></i>
            <p id="edit_upload_label">Click to upload new photo (replaces existing)</p>
          </div>
          <input type="file" id="edit_image_input" name="item_image" accept="image/*" style="display:none" onchange="previewImage(this,'edit_preview')">
          <div id="edit_preview" style="margin-top:8px;"></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label class="form-label">Category</label>
            <select name="category_id" id="edit_cat" class="form-control"><option value="0">-- Select --</option>
            <?php $cats->data_seek(0); while($c=$cats->fetch_assoc()): ?><option value="<?= $c['id'] ?>"><?= sanitize($c['name']) ?></option><?php endwhile; ?>
            </select></div>
          <div class="form-group"><label class="form-label">Supplier</label>
            <select name="supplier_id" id="edit_sup" class="form-control"><option value="0">-- Select --</option>
            <?php $sups->data_seek(0); while($s=$sups->fetch_assoc()): ?><option value="<?= $s['id'] ?>"><?= sanitize($s['name']) ?></option><?php endwhile; ?>
            </select></div>
        </div>
        <div class="form-grid-3">
          <div class="form-group"><label class="form-label">Unit</label><input type="text" name="unit" id="edit_unit" class="form-control"></div>
          <div class="form-group"><label class="form-label">Reorder Level</label><input type="number" name="reorder_level" id="edit_rol" class="form-control" min="0"></div>
          <div class="form-group"><label class="form-label">Unit Price (₱)</label><input type="number" name="unit_price" id="edit_price" class="form-control" step="0.01" min="0"></div>
        </div>
        <div class="form-grid">
          <div class="form-group"><label class="form-label">Storage Location</label><input type="text" name="location" id="edit_loc" class="form-control"></div>
          <div class="form-group"><label class="form-label">Status</label>
            <select name="status" id="edit_status" class="form-control"><option value="active">Active</option><option value="inactive">Inactive</option><option value="discontinued">Discontinued</option></select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Cancel</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Update Item</button>
      </div>
    </form>
  </div>
</div>

<script>
var currentBarcodeItem = null;
var baseUrl = '<?= BASE_URL ?>';

/* ── Image lightbox ── */
function showLightbox(src, name) {
  document.getElementById('lightboxImg').src = src;
  document.getElementById('lightboxImg').alt = name;
  document.getElementById('lightbox').style.display = 'flex';
}
function closeLightbox() { document.getElementById('lightbox').style.display = 'none'; }

/* ── Image preview before upload ── */
function previewImage(input, targetId) {
  var target = document.getElementById(targetId);
  target.innerHTML = '';
  if (!input.files || !input.files[0]) return;
  var reader = new FileReader();
  reader.onload = function(e) {
    var wrap = document.createElement('div');
    wrap.className = 'img-preview-wrap';
    var img = document.createElement('img');
    img.src = e.target.result;
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'remove-img';
    btn.innerHTML = '<i class="fas fa-times"></i>';
    btn.onclick = function() { target.innerHTML = ''; input.value = ''; };
    wrap.appendChild(img);
    wrap.appendChild(btn);
    target.appendChild(wrap);
  };
  reader.readAsDataURL(input.files[0]);
}

/* ── Remove existing image in edit ── */
function removeCurrentImage() {
  document.getElementById('edit_current_img_wrap').style.display = 'none';
  document.getElementById('edit_remove_image').value = '1';
  document.getElementById('edit_upload_label').textContent = 'Click to upload a new photo';
}

/* ── Edit modal populate ── */
function editItem(r) {
  document.getElementById('edit_id').value     = r.id;
  document.getElementById('edit_code').value   = r.item_code;
  document.getElementById('edit_name').value   = r.name;
  document.getElementById('edit_desc').value   = r.description || '';
  document.getElementById('edit_cat').value    = r.category_id || 0;
  document.getElementById('edit_sup').value    = r.supplier_id || 0;
  document.getElementById('edit_unit').value   = r.unit;
  document.getElementById('edit_rol').value    = r.reorder_level;
  document.getElementById('edit_price').value  = r.unit_price;
  document.getElementById('edit_loc').value    = r.location || '';
  document.getElementById('edit_status').value = r.status;
  document.getElementById('edit_remove_image').value = '0';
  document.getElementById('edit_preview').innerHTML  = '';
  document.getElementById('edit_image_input').value  = '';

  var imgWrap = document.getElementById('edit_current_img_wrap');
  var imgEl   = document.getElementById('edit_current_img');
  if (r.image) {
    imgEl.src = baseUrl + 'uploads/items/' + r.image;
    imgWrap.style.display = 'block';
    document.getElementById('edit_upload_label').textContent = 'Click to upload new photo (replaces existing)';
  } else {
    imgWrap.style.display = 'none';
    document.getElementById('edit_upload_label').textContent = 'Click to upload a photo';
  }
  openModal('editModal');
}

/* ── Render inline barcodes ── */
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.barcode-svg').forEach(function(svg) {
    var code = svg.getAttribute('data-code');
    try {
      JsBarcode(svg, code, { format:'CODE128', width:1.4, height:36, displayValue:false, margin:4, lineColor:'#1e2d54', background:'#ffffff' });
    } catch(e) { svg.style.display='none'; }
  });
});

/* ── Large barcode modal ── */
function showBarcode(item) {
  currentBarcodeItem = item;
  document.getElementById('bcItemName').textContent = item.name;
  document.getElementById('bcItemCode').textContent = item.item_code;
  var meta = [];
  if (item.cat_name) meta.push(item.cat_name);
  if (item.location) meta.push('📍 ' + item.location);
  meta.push('Qty: ' + item.quantity + ' ' + (item.unit||''));
  if (item.unit_price > 0) meta.push('₱ ' + parseFloat(item.unit_price).toFixed(2));
  document.getElementById('bcItemMeta').textContent = meta.join('  ·  ');
  JsBarcode(document.getElementById('bcLarge'), item.item_code, { format:'CODE128', width:2.8, height:90, displayValue:true, fontSize:14, fontOptions:'bold', textMargin:6, lineColor:'#000000', background:'#ffffff', margin:10 });
  openModal('barcodeModal');
}

function printBarcode() {
  if (!currentBarcodeItem) return;
  var svgEl  = document.getElementById('bcLarge');
  var svgStr = new XMLSerializer().serializeToString(svgEl);
  var svgB64 = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgStr)));
  var price  = parseFloat(currentBarcodeItem.unit_price||0).toFixed(2);
  var status = currentBarcodeItem.status||'active';
  var badgeColor = status==='active'?'#27ae60':(status==='inactive'?'#95a5a6':'#e74c3c');
  var imgHtml = '';
  if (currentBarcodeItem.image) {
    imgHtml = '<div style="margin-bottom:8px;"><img src="' + baseUrl + 'uploads/items/' + currentBarcodeItem.image + '" style="max-width:120px;max-height:80px;border-radius:6px;border:1px solid #e2e6f0;object-fit:cover;"></div>';
  }
  var html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Barcode — ' + currentBarcodeItem.item_code + '</title>'
    + '<link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;700&family=Barlow+Condensed:wght@700;800&display=swap" rel="stylesheet">'
    + '<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:Barlow,sans-serif;background:#fff;display:flex;justify-content:center;padding:12px;}'
    + '.label{width:80mm;border:1.5px solid #1e2d54;border-radius:8px;overflow:hidden;}'
    + '.lhead{background:#1e2d54;padding:7px 12px;}.lhead-name{font-family:"Barlow Condensed",sans-serif;font-size:13px;font-weight:800;letter-spacing:.8px;text-transform:uppercase;color:#e8c347;}'
    + '.lgold{height:3px;background:linear-gradient(90deg,#c9a227,#e8c347,#c9a227);}'
    + '.lbody{padding:10px 12px;text-align:center;}.lname{font-family:"Barlow Condensed",sans-serif;font-size:15px;font-weight:800;color:#1e2d54;margin:6px 0 3px;}'
    + '.lfooter{background:#f8f9fc;border-top:1px solid #e2e6f0;padding:5px 12px;display:flex;justify-content:space-between;align-items:center;}'
    + '.lstatus{font-size:8px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;padding:2px 8px;border-radius:20px;background:' + badgeColor + '22;color:' + badgeColor + ';}'
    + '@media print{@page{size:80mm auto;margin:2mm}body{padding:0}}</style></head><body><div class="label">'
    + '<div class="lhead"><div class="lhead-name">MacGuyver Enterprises</div></div>'
    + '<div class="lgold"></div>'
    + '<div class="lbody">' + imgHtml + '<img src="' + svgB64 + '" style="width:100%;height:auto;">'
    + '<div class="lname">' + currentBarcodeItem.name + '</div></div>'
    + '<div class="lfooter"><span class="lstatus">' + status + '</span><span style="font-size:9px;color:#5a6580;">&#8369; ' + price + ' / ' + (currentBarcodeItem.unit||'unit') + '</span></div>'
    + '</div><script>window.onload=function(){window.print();}<\/script></body></html>';
  var win = window.open('','_blank','width=360,height=560');
  win.document.open(); win.document.write(html); win.document.close();
}

function downloadBarcode() {
  var svgEl  = document.getElementById('bcLarge');
  var svgStr = new XMLSerializer().serializeToString(svgEl);
  var svgBlob = new Blob([svgStr], {type:'image/svg+xml;charset=utf-8'});
  var url = URL.createObjectURL(svgBlob);
  var img = new Image();
  img.onload = function() {
    var W=320,H=200;
    var oc = document.createElement('canvas');
    oc.width=W*2; oc.height=H*2;
    var ctx=oc.getContext('2d');
    ctx.scale(2,2);
    ctx.fillStyle='#fff'; ctx.fillRect(0,0,W,H);
    ctx.fillStyle='#1e2d54'; ctx.fillRect(0,0,W,36);
    ctx.fillStyle='#e8c347'; ctx.font='bold 13px Arial'; ctx.textAlign='center';
    ctx.fillText('MacGuyver Enterprises', W/2, 22);
    var g=ctx.createLinearGradient(0,36,W,36);
    g.addColorStop(0,'#c9a227'); g.addColorStop(.5,'#e8c347'); g.addColorStop(1,'#c9a227');
    ctx.fillStyle=g; ctx.fillRect(0,36,W,3);
    ctx.drawImage(img,10,44,W-20,100);
    ctx.fillStyle='#1e2d54'; ctx.font='bold 12px Arial'; ctx.textAlign='center';
    ctx.fillText(currentBarcodeItem.name.substring(0,38), W/2, 158);
    ctx.fillStyle='#5a6580'; ctx.font='9px Arial';
    ctx.fillText(currentBarcodeItem.item_code, W/2, 172);
    URL.revokeObjectURL(url);
    oc.toBlob(function(blob){
      var a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download='barcode-'+currentBarcodeItem.item_code+'.png';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
    },'image/png');
  };
  img.src=url;
}
</script>
<?php require_once '../includes/footer.php'; ?>
