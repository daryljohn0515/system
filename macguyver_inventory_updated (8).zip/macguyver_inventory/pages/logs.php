<?php
define('BASE_URL', '/macguyver_inventory/');
$pageTitle = 'Activity Logs';
require_once '../includes/header.php';
if (!isAdmin()) { header('Location: ../dashboard.php'); exit(); }
$db = getDB();

$search   = $db->real_escape_string($_GET['search'] ?? '');
$action_f = $db->real_escape_string($_GET['action_f'] ?? '');
$date_from= $db->real_escape_string($_GET['date_from'] ?? '');
$date_to  = $db->real_escape_string($_GET['date_to'] ?? '');

$perPage = 25;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where = "WHERE 1=1";
if ($search)   $where .= " AND (l.action LIKE '%$search%' OR l.description LIKE '%$search%' OR u.full_name LIKE '%$search%' OR u.username LIKE '%$search%')";
if ($action_f) $where .= " AND l.action='$action_f'";
if ($date_from)$where .= " AND DATE(l.created_at) >= '$date_from'";
if ($date_to)  $where .= " AND DATE(l.created_at) <= '$date_to'";

$total      = $db->query("SELECT COUNT(*) c FROM activity_logs l LEFT JOIN users u ON l.user_id=u.id $where")->fetch_assoc()['c'];
$totalPages = max(1, ceil($total / $perPage));

$logs = $db->query("SELECT l.*,u.full_name,u.username FROM activity_logs l LEFT JOIN users u ON l.user_id=u.id $where ORDER BY l.created_at DESC LIMIT $perPage OFFSET $offset");

$filterQS = http_build_query(array_filter(['search'=>$_GET['search']??'','action_f'=>$_GET['action_f']??'','date_from'=>$_GET['date_from']??'','date_to'=>$_GET['date_to']??'']));
$filterQS = $filterQS ? '&'.$filterQS : '';
?>
<style>
.pagination{display:flex;align-items:center;gap:6px;justify-content:flex-end;padding:14px 16px;flex-wrap:wrap}
.pag-btn{padding:5px 11px;border-radius:6px;border:1px solid var(--gray-200);background:#fff;color:var(--navy);font-size:.82rem;font-weight:600;text-decoration:none;transition:all .2s}
.pag-btn:hover{background:var(--navy);color:#fff}
.pag-btn.active{background:var(--navy);color:#fff;border-color:var(--navy)}
.pag-btn.disabled{opacity:.4;pointer-events:none}
</style>
<div class="page-header">
  <div><h1>Activity Logs</h1><p>System activity and audit trail &mdash; <?= number_format($total) ?> total entries</p></div>
  <button onclick="printPage()" class="btn btn-secondary"><i class="fas fa-print"></i> Print</button>
</div>
<div class="card">
  <div class="card-header" style="gap:12px;flex-wrap:wrap;">
    <h2><i class="fas fa-history" style="color:var(--gold)"></i> Activity Logs</h2>
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;">
      <input type="text" name="search" class="search-input" placeholder="Search user, action..." value="<?= htmlspecialchars($_GET['search']??'') ?>">
      <select name="action_f" class="form-control" style="width:auto">
        <option value="">All Actions</option>
        <?php foreach(['login','logout','add_item','edit_item','delete_item','stock_in','stock_out'] as $a): ?>
        <option value="<?= $a ?>" <?= $action_f===$a?'selected':'' ?>><?= ucwords(str_replace('_',' ',$a)) ?></option>
        <?php endforeach; ?>
      </select>
      <input type="date" name="date_from" class="form-control" style="width:auto" value="<?= htmlspecialchars($date_from) ?>">
      <input type="date" name="date_to"   class="form-control" style="width:auto" value="<?= htmlspecialchars($date_to) ?>">
      <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Filter</button>
      <a href="logs.php" class="btn btn-secondary btn-sm">Reset</a>
    </form>
  </div>
  <div class="table-responsive">
    <table>
      <thead><tr><th>#</th><th>User</th><th>Action</th><th>Description</th><th>IP Address</th><th>Date & Time</th></tr></thead>
      <tbody>
      <?php $rowNum=$offset+1; while($r=$logs->fetch_assoc()): ?>
      <tr>
        <td><?= $rowNum++ ?></td>
        <td><strong><?= sanitize($r['full_name']??'System') ?></strong><br><small class="item-code"><?= sanitize($r['username']??'') ?></small></td>
        <td><?php
          $actionColors=['login'=>'success','logout'=>'secondary','add_item'=>'info','edit_item'=>'warning','delete_item'=>'danger','stock_in'=>'success','stock_out'=>'danger'];
          $color=$actionColors[$r['action']]??'navy';
        ?><span class="badge badge-<?= $color ?>"><?= sanitize(str_replace('_',' ',$r['action'])) ?></span></td>
        <td><?= sanitize($r['description']) ?></td>
        <td><span class="item-code"><?= sanitize($r['ip_address']) ?></span></td>
        <td style="font-size:.78rem;color:var(--gray-600);white-space:nowrap"><?= date('M d, Y', strtotime($r['created_at'])) ?><br><?= date('g:i A', strtotime($r['created_at'])) ?></td>
      </tr>
      <?php endwhile; ?>
      <?php if($total===0): ?><tr><td colspan="6"><div class="empty-state"><i class="fas fa-search"></i><p>No logs found.</p></div></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($totalPages>1): ?>
  <div class="pagination">
    <a href="?page=1<?= $filterQS ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-double-left"></i></a>
    <a href="?page=<?= max(1,$page-1) ?><?= $filterQS ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-left"></i></a>
    <?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++): ?>
      <a href="?page=<?= $p ?><?= $filterQS ?>" class="pag-btn <?= $p==$page?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
    <a href="?page=<?= min($totalPages,$page+1) ?><?= $filterQS ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-right"></i></a>
    <a href="?page=<?= $totalPages ?><?= $filterQS ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-double-right"></i></a>
    <span style="font-size:.8rem;color:var(--gray-600);margin-left:6px">Page <?= $page ?> of <?= $totalPages ?> &nbsp;|&nbsp; Showing <?= $offset+1 ?>&#8211;<?= min($offset+$perPage,$total) ?> of <?= number_format($total) ?></span>
  </div>
  <?php endif; ?>
</div>
<?php require_once '../includes/footer.php'; ?>
