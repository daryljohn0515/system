<?php
define('BASE_URL', '/macguyver_inventory/');
$pageTitle = 'Reports';
require_once '../includes/header.php';
$db = getDB();

$report    = $_GET['report'] ?? 'inventory';
$date_from = $_GET['date_from'] ?? date('Y-m-01');
$date_to   = $_GET['date_to'] ?? date('Y-m-d');

$perPage = 25;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$filterQS = http_build_query(array_filter(['report'=>$report,'date_from'=>$date_from,'date_to'=>$date_to]));
$filterQS = $filterQS ? '&'.$filterQS : '';
?>
<style>
.pagination{display:flex;align-items:center;gap:6px;justify-content:flex-end;padding:14px 16px;flex-wrap:wrap}
.pag-btn{padding:5px 11px;border-radius:6px;border:1px solid var(--gray-200);background:#fff;color:var(--navy);font-size:.82rem;font-weight:600;text-decoration:none;transition:all .2s}
.pag-btn:hover{background:var(--navy);color:#fff}
.pag-btn.active{background:var(--navy);color:#fff;border-color:var(--navy)}
.pag-btn.disabled{opacity:.4;pointer-events:none}
</style>

<div class="page-header">
  <div><h1>Reports</h1><p>Generate and print inventory reports</p></div>
  <button onclick="printPage()" class="btn btn-secondary"><i class="fas fa-print"></i> Print Report</button>
</div>

<!-- Report Tabs -->
<div style="display:flex;gap:10px;margin-bottom:24px;flex-wrap:wrap;">
  <a href="?report=inventory&page=1" class="btn <?= $report==='inventory'?'btn-gold':'btn-outline-navy btn-outline' ?>"><i class="fas fa-boxes"></i> Inventory Status</a>
  <a href="?report=low_stock&page=1" class="btn <?= $report==='low_stock'?'btn-gold':'btn-outline-navy btn-outline' ?>"><i class="fas fa-exclamation-triangle"></i> Low Stock</a>
  <a href="?report=transactions&date_from=<?= $date_from ?>&date_to=<?= $date_to ?>&page=1" class="btn <?= $report==='transactions'?'btn-gold':'btn-outline-navy btn-outline' ?>"><i class="fas fa-exchange-alt"></i> Transaction Report</a>
  <a href="?report=valuation&page=1" class="btn <?= $report==='valuation'?'btn-gold':'btn-outline-navy btn-outline' ?>"><i class="fas fa-peso-sign"></i> Inventory Valuation</a>
</div>

<?php if($report === 'transactions'): ?>
<form method="GET" style="background:#fff;padding:16px 20px;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,.06);margin-bottom:20px;display:flex;gap:12px;align-items:center;flex-wrap:wrap;">
  <input type="hidden" name="report" value="transactions">
  <label class="form-label" style="margin:0">From:</label>
  <input type="date" name="date_from" class="form-control" style="width:auto" value="<?= $date_from ?>">
  <label class="form-label" style="margin:0">To:</label>
  <input type="date" name="date_to" class="form-control" style="width:auto" value="<?= $date_to ?>">
  <button type="submit" class="btn btn-primary btn-sm"><i class="fas fa-filter"></i> Generate</button>
</form>
<?php endif; ?>

<?php if($report === 'inventory'): ?>
<?php
$df = $db->real_escape_string($date_from); $dt = $db->real_escape_string($date_to);
$total_val = $db->query("SELECT SUM(quantity*unit_price) v FROM items WHERE status='active'")->fetch_assoc()['v'];
$total     = $db->query("SELECT COUNT(*) c FROM items i LEFT JOIN categories c ON i.category_id=c.id LEFT JOIN suppliers s ON i.supplier_id=s.id WHERE i.status='active'")->fetch_assoc()['c'];
$totalPages = max(1, ceil($total / $perPage));
$items = $db->query("SELECT i.*,c.name cat_name,s.name sup_name FROM items i LEFT JOIN categories c ON i.category_id=c.id LEFT JOIN suppliers s ON i.supplier_id=s.id WHERE i.status='active' ORDER BY c.name,i.name LIMIT $perPage OFFSET $offset");
?>
<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-boxes" style="color:var(--gold)"></i> Inventory Status Report &mdash; <?= date('F d, Y') ?></h2>
    <small style="color:var(--gray-600)"><?= number_format($total) ?> items | Total Value: <?= formatCurrency($total_val??0) ?></small>
  </div>
  <div class="table-responsive">
    <table>
      <thead><tr><th>#</th><th>Item Code</th><th>Item Name</th><th>Category</th><th>Supplier</th><th>Unit</th><th>Qty</th><th>Unit Price</th><th>Total Value</th><th>Status</th></tr></thead>
      <tbody>
      <?php $rowNum=$offset+1; while($r=$items->fetch_assoc()): ?>
      <tr>
        <td><?= $rowNum++ ?></td>
        <td><span class="item-code"><?= sanitize($r['item_code']) ?></span></td>
        <td><?= sanitize($r['name']) ?></td>
        <td><?= sanitize($r['cat_name']??'-') ?></td>
        <td><?= sanitize($r['sup_name']??'-') ?></td>
        <td><?= sanitize($r['unit']) ?></td>
        <td class="<?= $r['quantity']==0?'out-stock':($r['quantity']<=$r['reorder_level']?'low-stock':'') ?>"><?= $r['quantity'] ?></td>
        <td><?= formatCurrency($r['unit_price']) ?></td>
        <td><?= formatCurrency($r['quantity']*$r['unit_price']) ?></td>
        <td><?php if($r['quantity']==0): ?><span class="badge badge-danger">Out of Stock</span>
            <?php elseif($r['quantity']<=$r['reorder_level']): ?><span class="badge badge-warning">Low Stock</span>
            <?php else: ?><span class="badge badge-success">OK</span><?php endif; ?></td>
      </tr>
      <?php endwhile; ?>
      </tbody>
      <tfoot><tr><td colspan="8" style="text-align:right;font-weight:700;padding:12px 14px">TOTAL INVENTORY VALUE:</td><td colspan="2" style="font-weight:700;color:var(--navy);font-size:1rem;padding:12px 14px"><?= formatCurrency($total_val??0) ?></td></tr></tfoot>
    </table>
  </div>
  <?php if($totalPages>1): ?>
  <div class="pagination">
    <a href="?report=inventory&page=1" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-double-left"></i></a>
    <a href="?report=inventory&page=<?= max(1,$page-1) ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-left"></i></a>
    <?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++): ?>
      <a href="?report=inventory&page=<?= $p ?>" class="pag-btn <?= $p==$page?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
    <a href="?report=inventory&page=<?= min($totalPages,$page+1) ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-right"></i></a>
    <a href="?report=inventory&page=<?= $totalPages ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-double-right"></i></a>
    <span style="font-size:.8rem;color:var(--gray-600);margin-left:6px">Page <?= $page ?> of <?= $totalPages ?> &nbsp;|&nbsp; Showing <?= $offset+1 ?>&#8211;<?= min($offset+$perPage,$total) ?> of <?= number_format($total) ?></span>
  </div>
  <?php endif; ?>
</div>

<?php elseif($report === 'low_stock'): ?>
<?php
$total = $db->query("SELECT COUNT(*) c FROM items i LEFT JOIN categories c ON i.category_id=c.id WHERE i.quantity <= i.reorder_level AND i.status='active'")->fetch_assoc()['c'];
$totalPages = max(1, ceil($total / $perPage));
$items = $db->query("SELECT i.*,c.name cat_name FROM items i LEFT JOIN categories c ON i.category_id=c.id WHERE i.quantity <= i.reorder_level AND i.status='active' ORDER BY i.quantity ASC LIMIT $perPage OFFSET $offset");
?>
<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-exclamation-triangle" style="color:var(--orange)"></i> Low Stock Report &mdash; <?= date('F d, Y') ?></h2>
    <small style="color:var(--gray-600)"><?= number_format($total) ?> items needing attention</small>
  </div>
  <div class="table-responsive">
    <table>
      <thead><tr><th>#</th><th>Item Code</th><th>Item Name</th><th>Category</th><th>Current Qty</th><th>Reorder Level</th><th>Unit</th><th>Unit Price</th><th>Status</th></tr></thead>
      <tbody>
      <?php $rowNum=$offset+1; while($r=$items->fetch_assoc()): ?>
      <tr>
        <td><?= $rowNum++ ?></td>
        <td><span class="item-code"><?= sanitize($r['item_code']) ?></span></td>
        <td><strong><?= sanitize($r['name']) ?></strong></td>
        <td><?= sanitize($r['cat_name']??'-') ?></td>
        <td class="<?= $r['quantity']==0?'out-stock':'low-stock' ?>"><?= $r['quantity'] ?></td>
        <td><?= $r['reorder_level'] ?></td>
        <td><?= sanitize($r['unit']) ?></td>
        <td><?= formatCurrency($r['unit_price']) ?></td>
        <td><?= $r['quantity']==0?'<span class="badge badge-danger">Out of Stock</span>':'<span class="badge badge-warning">Low Stock</span>' ?></td>
      </tr>
      <?php endwhile; ?>
      <?php if($total===0): ?><tr><td colspan="9"><div class="empty-state"><i class="fas fa-check-circle" style="color:var(--green)"></i><p>All items are well stocked!</p></div></td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($totalPages>1): ?>
  <div class="pagination">
    <a href="?report=low_stock&page=1" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-double-left"></i></a>
    <a href="?report=low_stock&page=<?= max(1,$page-1) ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-left"></i></a>
    <?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++): ?>
      <a href="?report=low_stock&page=<?= $p ?>" class="pag-btn <?= $p==$page?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
    <a href="?report=low_stock&page=<?= min($totalPages,$page+1) ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-right"></i></a>
    <a href="?report=low_stock&page=<?= $totalPages ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-double-right"></i></a>
    <span style="font-size:.8rem;color:var(--gray-600);margin-left:6px">Page <?= $page ?> of <?= $totalPages ?></span>
  </div>
  <?php endif; ?>
</div>

<?php elseif($report === 'transactions'): ?>
<?php
$df = $db->real_escape_string($date_from); $dt = $db->real_escape_string($date_to);
$summary = $db->query("SELECT type,COUNT(*) cnt,SUM(quantity) total_qty FROM transactions WHERE DATE(transaction_date) BETWEEN '$df' AND '$dt' GROUP BY type");
$total   = $db->query("SELECT COUNT(*) c FROM transactions t LEFT JOIN items i ON t.item_id=i.id WHERE DATE(t.transaction_date) BETWEEN '$df' AND '$dt'")->fetch_assoc()['c'];
$totalPages = max(1, ceil($total / $perPage));
$txns = $db->query("SELECT t.*,i.name iname,i.unit,u.full_name uname FROM transactions t LEFT JOIN items i ON t.item_id=i.id LEFT JOIN users u ON t.performed_by=u.id WHERE DATE(t.transaction_date) BETWEEN '$df' AND '$dt' ORDER BY t.transaction_date DESC LIMIT $perPage OFFSET $offset");
$txnQS = '&date_from='.urlencode($date_from).'&date_to='.urlencode($date_to);
?>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:16px;margin-bottom:20px;">
<?php while($s=$summary->fetch_assoc()): ?>
<div class="stat-card" style="border-left-color:<?= $s['type']==='stock_in'?'var(--green)':'var(--red)' ?>">
  <div class="stat-icon <?= $s['type']==='stock_in'?'green':'red' ?>"><i class="fas fa-<?= $s['type']==='stock_in'?'arrow-down':'arrow-up' ?>"></i></div>
  <div class="stat-info"><h3><?= $s['cnt'] ?></h3><p><?= ucfirst(str_replace('_',' ',$s['type'])) ?> (<?= $s['total_qty'] ?> units)</p></div>
</div>
<?php endwhile; ?>
</div>
<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-exchange-alt" style="color:var(--gold)"></i> Transactions: <?= date('M d, Y', strtotime($date_from)) ?> &mdash; <?= date('M d, Y', strtotime($date_to)) ?></h2>
    <small style="color:var(--gray-600)"><?= number_format($total) ?> records</small>
  </div>
  <div class="table-responsive">
    <table>
      <thead><tr><th>#</th><th>Code</th><th>Item</th><th>Type</th><th>Qty</th><th>Reference</th><th>By</th><th>Date</th></tr></thead>
      <tbody>
      <?php $rowNum=$offset+1; while($r=$txns->fetch_assoc()): ?>
      <tr>
        <td><?= $rowNum++ ?></td>
        <td><span class="item-code"><?= sanitize($r['transaction_code']) ?></span></td>
        <td><?= sanitize($r['iname']??'-') ?></td>
        <td><?php if($r['type']==='stock_in'): ?><span class="badge badge-success">Stock In</span><?php else: ?><span class="badge badge-danger">Stock Out</span><?php endif; ?></td>
        <td style="font-weight:600;color:<?= $r['type']==='stock_in'?'var(--green)':'var(--red)' ?>"><?= ($r['type']==='stock_in'?'+':'-').$r['quantity'].' '.sanitize($r['unit']??'') ?></td>
        <td><?= sanitize($r['reference_no']??'-') ?></td>
        <td><?= sanitize($r['uname']??'System') ?></td>
        <td style="font-size:.78rem"><?= date('M d, Y g:i A', strtotime($r['transaction_date'])) ?></td>
      </tr>
      <?php endwhile; ?>
      <?php if($total===0): ?><tr><td colspan="8" style="text-align:center;padding:24px;color:var(--gray-400)">No transactions in this period.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($totalPages>1): ?>
  <div class="pagination">
    <a href="?report=transactions&page=1<?= $txnQS ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-double-left"></i></a>
    <a href="?report=transactions&page=<?= max(1,$page-1) ?><?= $txnQS ?>" class="pag-btn <?= $page<=1?'disabled':'' ?>"><i class="fas fa-angle-left"></i></a>
    <?php for($p=max(1,$page-2);$p<=min($totalPages,$page+2);$p++): ?>
      <a href="?report=transactions&page=<?= $p ?><?= $txnQS ?>" class="pag-btn <?= $p==$page?'active':'' ?>"><?= $p ?></a>
    <?php endfor; ?>
    <a href="?report=transactions&page=<?= min($totalPages,$page+1) ?><?= $txnQS ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-right"></i></a>
    <a href="?report=transactions&page=<?= $totalPages ?><?= $txnQS ?>" class="pag-btn <?= $page>=$totalPages?'disabled':'' ?>"><i class="fas fa-angle-double-right"></i></a>
    <span style="font-size:.8rem;color:var(--gray-600);margin-left:6px">Page <?= $page ?> of <?= $totalPages ?> &nbsp;|&nbsp; Showing <?= $offset+1 ?>&#8211;<?= min($offset+$perPage,$total) ?> of <?= number_format($total) ?></span>
  </div>
  <?php endif; ?>
</div>

<?php elseif($report === 'valuation'): ?>
<?php
$cats  = $db->query("SELECT c.name,COUNT(i.id) item_count,SUM(i.quantity) total_qty,SUM(i.quantity*i.unit_price) total_val FROM categories c LEFT JOIN items i ON i.category_id=c.id AND i.status='active' GROUP BY c.id,c.name ORDER BY total_val DESC");
$grand = $db->query("SELECT SUM(quantity*unit_price) v FROM items WHERE status='active'")->fetch_assoc()['v'];
?>
<div class="card">
  <div class="card-header">
    <h2><i class="fas fa-peso-sign" style="color:var(--gold)"></i> Inventory Valuation Report &mdash; <?= date('F d, Y') ?></h2>
    <small style="color:var(--gray-600)">Grand Total: <?= formatCurrency($grand??0) ?></small>
  </div>
  <div class="table-responsive">
    <table>
      <thead><tr><th>#</th><th>Category</th><th>Items</th><th>Total Units</th><th>Total Value</th><th>% of Total</th></tr></thead>
      <tbody>
      <?php $i=1; while($r=$cats->fetch_assoc()): $pct=$grand>0?round(($r['total_val']/$grand)*100,1):0; ?>
      <tr>
        <td><?= $i++ ?></td>
        <td><strong><?= sanitize($r['name']) ?></strong></td>
        <td><?= $r['item_count']??0 ?></td>
        <td><?= $r['total_qty']??0 ?></td>
        <td><strong><?= formatCurrency($r['total_val']??0) ?></strong></td>
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div class="progress" style="flex:1"><div class="progress-bar green" style="width:<?= $pct ?>%"></div></div>
            <span style="font-size:.78rem;min-width:35px"><?= $pct ?>%</span>
          </div>
        </td>
      </tr>
      <?php endwhile; ?>
      </tbody>
      <tfoot><tr><td colspan="4" style="text-align:right;font-weight:700;padding:12px 14px">GRAND TOTAL:</td><td colspan="2" style="font-weight:700;color:var(--navy);font-size:1.05rem;padding:12px 14px"><?= formatCurrency($grand??0) ?></td></tr></tfoot>
    </table>
  </div>
</div>
<?php endif; ?>
<?php require_once '../includes/footer.php'; ?>
