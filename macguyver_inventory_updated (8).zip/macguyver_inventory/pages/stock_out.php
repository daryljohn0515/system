<?php header("Location: stock_in_out.php?tab=stock_out"); exit(); ?>
